<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; ProMahmudul  <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer><?php /**PATH E:\xampp\htdocs\laravel\prothom-alo\resources\views/admin/inc/footer.blade.php ENDPATH**/ ?>