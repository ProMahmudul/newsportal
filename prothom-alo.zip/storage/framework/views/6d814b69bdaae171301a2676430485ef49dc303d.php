<?php $__env->startSection('page-title'); ?>
    Add Post - Prothom Alo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-heading'); ?>
    <span class="badge badge-primary">Post</span> -
    <small>Add new post</small>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if(Session::has('message')): ?>
        <div class="alert <?php echo e(Session::get('alert_type')); ?> alert-dismissible fade show" data-auto-dismiss>
            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <strong>Success!</strong> <?php echo e(Session::get('message')); ?>.
        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card card-body">
        <form action="<?php echo e(route('post.store')); ?>" method="POST" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="row" class="bg-white">
                <div class="col-md-9">
                    <div class="form-group">
                        <label for="title">Add New Post</label>
                        <input type="text" class="form-control" name="title" id="title" placeholder="Enter title here" required>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="description" rows="10"></textarea>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-block" value="Publish">
                    </div>
                    <div class="form-group row">
                        <label for="category">Category</label>
                        <select name="category" id="category" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="image">Featured Image</label>
                        <input type="file" class="form-control" name="image" id="image">
                    </div>
                </div>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\prothom-alo\resources\views/admin/posts/add-post.blade.php ENDPATH**/ ?>